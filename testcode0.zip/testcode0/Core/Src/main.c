/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : AC電圧センサー計測（ZMPT101B + STM32F4xx Nucleo）
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include <string.h>
#include <math.h>
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BUF_SIZE 200
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef  hadc1;
TIM_HandleTypeDef  htim2;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
static uint16_t          adcBuf[BUF_SIZE];
static volatile uint16_t writeIndex  = 0;
static volatile bool     bufferReady = false;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
static void ProcessBuffer(void);
static void UART_Print(const char *str);
static void UART_PrintFloat(float val, uint8_t decimals);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();

  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if (bufferReady)
    {
      ProcessBuffer();
      bufferReady = false;
      HAL_ADC_Start_IT(&hadc1);
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2)
  {
    if (!bufferReady)
    {
      HAL_ADC_Start_IT(&hadc1);
    }
  }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
  if (hadc->Instance == ADC1)
  {
    adcBuf[writeIndex] = (uint16_t)HAL_ADC_GetValue(hadc);
    writeIndex++;

    if (writeIndex >= BUF_SIZE)
    {
      writeIndex  = 0;
      bufferReady = true;
      HAL_ADC_Stop_IT(hadc);
    }
  }
}

static void ProcessBuffer(void)
{
  /* --- DC オフセット計算 --- */
  float sum = 0.0f;
  for (uint16_t i = 0; i < BUF_SIZE; i++)
  {
    sum += (adcBuf[i] * 3.3f) / 4095.0f;
  }
  float dcOffset = sum / BUF_SIZE;

  /* --- AC 実効値（RMS）計算 --- */
  float sumSquares = 0.0f;
  for (uint16_t i = 0; i < BUF_SIZE; i++)
  {
    float voltage   = (adcBuf[i] * 3.3f) / 4095.0f;
    float acVoltage = voltage - dcOffset;
    sumSquares += acVoltage * acVoltage;
  }
  float acRms = sqrtf(sumSquares / BUF_SIZE);

  /* --- 周波数計算（線形補間ゼロクロス法） --- */
  float zeroCrossTimes[20];
  int   zeroCrossCount = 0;
  bool  wasPositive    = (((adcBuf[0] * 3.3f) / 4095.0f) - dcOffset) >= 0.0f;
  float prevVoltage    = (adcBuf[0] * 3.3f) / 4095.0f - dcOffset;

  for (uint16_t i = 1; i < BUF_SIZE && zeroCrossCount < 20; i++)
  {
    float voltage    = (adcBuf[i] * 3.3f) / 4095.0f - dcOffset;
    bool  isPositive = (voltage >= 0.0f);

    if (wasPositive && !isPositive)
    {
      /* 線形補間: t_zero = (i-1) + |V[i-1]| / (|V[i-1]| + |V[i]|) */
      float t = (float)(i - 1)
              + fabsf(prevVoltage) / (fabsf(prevVoltage) + fabsf(voltage));
      zeroCrossTimes[zeroCrossCount] = t * 0.001f;  /* サンプル→秒 */
      zeroCrossCount++;
    }
    wasPositive = isPositive;
    prevVoltage = voltage;
  }

  /* --- 平均周期・周波数を計算（2パス外れ値除外） --- */
  /* 外れ値判定の閾値: 仮平均からこの割合以上ずれたintervalを除外 */
#define OUTLIER_RATIO 0.2f   /* 20%ずれで除外（例: 50Hz→20ms±4ms以上はNG） */

  float frequency  = 0.0f;
  float avgPeriod  = 0.0f;
  int   validCount = 0;    /* 外れ値除外後の有効interval数 */

  if (zeroCrossCount >= 2)
  {
    /* --- パス1: 全intervalの仮平均を計算 --- */
    float intervals[19];   /* interval最大数 = zeroCrossCount-1 = 19 */
    float sumPeriod   = 0.0f;
    int   intervalCount = zeroCrossCount - 1;

    for (int i = 0; i < intervalCount; i++)
    {
      intervals[i] = zeroCrossTimes[i + 1] - zeroCrossTimes[i];
      sumPeriod += intervals[i];
    }
    float roughAvg = sumPeriod / (float)intervalCount;

    /* --- パス2: 仮平均からOUTLIER_RATIO以上ずれたものを除外して再計算 --- */
    float sumValid = 0.0f;
    validCount     = 0;

    for (int i = 0; i < intervalCount; i++)
    {
      float deviation = fabsf(intervals[i] - roughAvg) / roughAvg;
      if (deviation <= OUTLIER_RATIO)
      {
        sumValid += intervals[i];
        validCount++;
      }
    }

    if (validCount >= 1)
    {
      avgPeriod = sumValid / (float)validCount;
      frequency = 1.0f / avgPeriod;
    }
  }

  /* --- 実AC電圧換算 --- */
  float transformRatio = 500.0f;   /* 要キャリブレーション */
  float realVoltage    = acRms * transformRatio;

  /* --- シリアル出力 --- */
  UART_Print("=== Measurement ===\r\n");

  UART_Print("DC Offset: ");
  UART_PrintFloat(dcOffset, 3);
  UART_Print(" V");
  if (fabsf(dcOffset - 1.65f) > 0.2f)
  {
    UART_Print(" [WARNING: Adjust to 1.65V!]");
  }
  UART_Print("\r\n");

  UART_Print("AC RMS (sensor): ");
  UART_PrintFloat(acRms, 3);
  UART_Print(" V\r\n");

  UART_Print("Real AC Voltage: ");
  UART_PrintFloat(realVoltage, 1);
  UART_Print(" V\r\n");

  UART_Print("Frequency: ");
  UART_PrintFloat(frequency, 2);
  UART_Print(" Hz");
  if      (frequency > 45.0f && frequency < 55.0f) { UART_Print(" (50Hz)");      }
  else if (frequency > 55.0f && frequency < 65.0f) { UART_Print(" (60Hz)");      }
  else if (frequency > 0.1f)                        { UART_Print(" [Abnormal!]"); }
  else                                              { UART_Print(" [No signal]"); }
  UART_Print("\r\n");

  /* --- ゼロクロス詳細出力 --- */
  UART_Print("Zero-cross detail:\r\n");
  UART_Print("  Count: ");
  UART_PrintFloat((float)zeroCrossCount, 0);
  UART_Print("  Valid intervals: ");
  UART_PrintFloat((float)validCount, 0);
  UART_Print("/");
  UART_PrintFloat((float)(zeroCrossCount - 1), 0);
  UART_Print("\r\n");

  UART_Print("  Avg period (filtered): ");
  UART_PrintFloat(avgPeriod * 1000.0f, 4);
  UART_Print(" ms\r\n");

  /* パス1の仮平均を表示用に再計算 */
  float roughAvgDisp = 0.0f;
  if (zeroCrossCount >= 2)
  {
    float s = 0.0f;
    for (int i = 1; i < zeroCrossCount; i++)
      s += zeroCrossTimes[i] - zeroCrossTimes[i - 1];
    roughAvgDisp = s / (float)(zeroCrossCount - 1);
  }

  for (int i = 0; i < zeroCrossCount; i++)
  {
    UART_Print("  [");
    UART_PrintFloat((float)i, 0);
    UART_Print("] t=");
    UART_PrintFloat(zeroCrossTimes[i] * 1000.0f, 4);
    UART_Print(" ms");

    if (i > 0)
    {
      float interval  = zeroCrossTimes[i] - zeroCrossTimes[i - 1];
      float deviation = fabsf(interval - roughAvgDisp) / roughAvgDisp;
      bool  outlier   = (deviation > OUTLIER_RATIO);

      UART_Print("  interval=");
      UART_PrintFloat(interval * 1000.0f, 4);
      UART_Print(" ms");

      float jitter = (interval - avgPeriod) * 1000.0f;
      UART_Print("  jitter=");
      UART_PrintFloat(jitter, 4);
      UART_Print(" ms");

      if (outlier) { UART_Print("  [OUTLIER]"); }
    }
    UART_Print("\r\n");
  }

  UART_Print("---- END ----\r\n\r\n");
}

static void UART_Print(const char *str)
{
  HAL_UART_Transmit(&huart2, (uint8_t *)str, (uint16_t)strlen(str), HAL_MAX_DELAY);
}

static void UART_PrintFloat(float val, uint8_t decimals)
{
  char buf[32];
  int  intPart  = (int)val;
  int  fracMult = 1;
  for (uint8_t i = 0; i < decimals; i++) fracMult *= 10;
  int fracPart = (int)fabsf((val - (float)intPart) * (float)fracMult);

  if (decimals == 0)
    snprintf(buf, sizeof(buf), "%d", intPart);
  else
    snprintf(buf, sizeof(buf), "%d.%0*d", intPart, decimals, fracPart);

  UART_Print(buf);
}

/* USER CODE END 4 */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM       = 8;
  RCC_OscInitStruct.PLL.PLLN       = 336;
  RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ       = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}

static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig   = {0};
  ADC_MultiModeTypeDef   multimode = {0};

  hadc1.Instance                   = ADC1;
  hadc1.Init.ClockPrescaler        = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution            = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode          = DISABLE;
  hadc1.Init.ContinuousConvMode    = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge  = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv      = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign             = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion       = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection          = ADC_EOC_SINGLE_CONV;
  HAL_ADC_Init(&hadc1);

  multimode.Mode = ADC_MODE_INDEPENDENT;
  HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode);

  sConfig.Channel      = ADC_CHANNEL_0;
  sConfig.Rank         = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
  sConfig.Offset       = 0;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}

static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef  sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig      = {0};

  htim2.Instance               = TIM2;
  htim2.Init.Prescaler         = 83;
  htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim2.Init.Period            = 999;
  htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  HAL_TIM_Base_Init(&htim2);

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig);

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
  HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig);
}

static void MX_USART2_UART_Init(void)
{
  huart2.Instance          = USART2;
  huart2.Init.BaudRate     = 115200;
  huart2.Init.WordLength   = UART_WORDLENGTH_8B;
  huart2.Init.StopBits     = UART_STOPBITS_1;
  huart2.Init.Parity       = UART_PARITY_NONE;
  huart2.Init.Mode         = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart2);
}

static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
}

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1) {}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  (void)file;
  (void)line;
  /* USER CODE END 6 */
}
#endif
